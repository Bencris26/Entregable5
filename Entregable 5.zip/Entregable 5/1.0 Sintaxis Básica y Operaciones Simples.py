# Imprimir un mensaje en la consola
print("¡Hola, bienvenidos al laboratorio de Python!")

# Declarar variables de diferentes tipos
entero = 10
flotante = 15.5
cadena = "Hola Mundo"

# Operaciones matemáticas simples
suma = entero + flotante
resta = flotante - entero
multiplicacion = entero * 2
division = flotante / 2

# Concatenar cadenas de texto
nombre = input("¿Cuál es tu nombre? ")
print("Hola, " + nombre + "! Bienvenido al laboratorio.")
